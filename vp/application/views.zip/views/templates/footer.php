<!-- CONTENT-WRAPPER SECTION END-->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    &copy; 2017 SDM OFFICE - NAINITAL | By : <a href="#" target="_blank">teamfreelancers</a>
                </div>

            </div>
        </div>
    </footer>
    <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY SCRIPTS -->
    <script src="<?php echo base_url('assets_/js/jquery-1.11.1.js');?>"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="<?php echo base_url('assets_/js/bootstrap.js');?>"></script>
    <script src="<?php echo base_url('assets_/js/myjs.js');?>"></script>
    <script src="<?php echo base_url('assets_/js/adminJS.js');?>"></script>
</body>
</html>
